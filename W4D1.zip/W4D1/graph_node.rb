class GraphNode
    
    def initialize(value)
        self.value = value
        self.neighbors = []
    end


    def bfs(st_node, trgt_node)

        queue = [st_node]
        visited = Set.new()

        until queue.empty?
            node = queue.shift

            unless visited.include?(node)
                return node.value if node.value == target_value
                visited.add(node)
                queue += node.neighbors
            end
        end
        nil
    end
end
