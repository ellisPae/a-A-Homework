class Stack

  def initialize(n)
    @stack = []
  end


  def push(ele)
    @stack.push(ele)
  end


  def pop
    @stack.pop
  end


  def peek
    @stack.last
  end

end






class Queue

  def initialize
    @line = []
  end


  def enqueue(ele)
    @line.push(ele)
    ele
  end


  def dequeue
    @line.shift
  end


  def peek
    @line.first
  end

end






class Map

  attr_reader :platform


  def initialize
    @platform = []
  end


  def set(key, value)
    idx_pair = @platform.index { |pair| pair[0] == key}
    idx_pair ? @platform[idx_pair][1] = value : @platform.push([key, value])
    value
  end


  def get(key)
    @platform.each { |pair| return pair[1] if pair[0] == key}
    nil
  end


  def delete(key)
    value = self.get(key)
    @platform.reject! { |pair| pair[0] == key}
    value
  end


  def show
    @platform
  end


end
