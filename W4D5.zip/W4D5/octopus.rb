
def sluggish_octopus(fishes)
    longest = fishes[0]

    (0...fishes.length).each do |i|
        temp_arr = []
        (i+1...fishes.length).each do |j|
            # longest = fishes[i][j] if fishes[i][j].length > longest.length
            temp_arr << fishes[i][j] if fishes[i][j].length > longest.length
        end
        longest << temp_ar
    end
    longest
end


class Array

  def merge_sort(&prc)
    prc ||= Proc.new { |a, b| a <=> b }

    return self if self.length <= 1

    midpoint = count / 2
    sorted_left = self.take(midpoint).merge_sort(&prc)
    sorted_right = self.drop(midpoint).merge_sort(&prc)

    Array.merge(sorted_left, sorted_right, &prc)
  end

  private
  def self.merge(left, right, &prc)
    merged = []

    until left.empty? || right.empty?
      case prc.call(left.first, right.first)
      when -1
        merged << left.shift
      when 0
        merged << left.shift
      when 1
        merged << right.shift
      end
    end

    merged + left + right
  end

end

def dominant_oct(fishes)
  prc = Proc.new { |a, b| a.length <=> b.length }
  fishes.merge_sort(&prc).last
end


def clever_oct(fishes)
    fishes.max_by(&:length)
end
